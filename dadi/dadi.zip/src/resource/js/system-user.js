import '../css/system-user.scss';

const util = require("./common/util.js")

function bindEvents(){
    var $doc = $(document);
    
}
function init(){
	bindEvents();
}
init();