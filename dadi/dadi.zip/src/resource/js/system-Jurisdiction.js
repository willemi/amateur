import '../css/system-Jurisdiction.scss';

const util = require("./common/util.js")

function bindEvents(){
    var $doc = $(document);
    
}
function init(){
	bindEvents();
}
init();