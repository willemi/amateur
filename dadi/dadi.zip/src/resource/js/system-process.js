import '../css/system-process.scss';

const util = require("./common/util.js")

function bindEvents(){
    var $doc = $(document);
    
}
function init(){
	bindEvents();
}
init();