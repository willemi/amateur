<template>
  <div id="Foo">
    <div>
        {{msg}}
    </div>
  </div>
</template>

<script>
export default {
  data() {
    return {
      msg: "我是老2",
    }
  }
}
</script>